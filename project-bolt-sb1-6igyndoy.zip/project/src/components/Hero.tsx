import { BarChart3, TrendingUp } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white py-20 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:60px_60px]" />
      <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-2 text-sm text-blue-300">
              <BarChart3 className="w-4 h-4" />
              <span>Profesyonel İstatistiksel Danışmanlık</span>
            </div>

            <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
              Akademik Araştırmanızı
              <span className="block text-blue-400 mt-2">Güçlü Analizlerle Destekleyin</span>
            </h1>

            <p className="text-xl text-slate-300 leading-relaxed">
              Tez ve makaleleriniz için uzman istatistik danışmanlığı. SPSS, R, Python ile profesyonel veri analizi, raporlama ve yorumlama hizmetleri.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#contact"
                className="inline-flex items-center justify-center px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-all duration-200 shadow-lg hover:shadow-blue-500/25 hover:-translate-y-0.5"
              >
                Ücretsiz Teklif Alın
              </a>
              <a
                href="#services"
                className="inline-flex items-center justify-center px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-lg backdrop-blur-sm border border-white/10 transition-all duration-200"
              >
                Hizmetleri İnceleyin
              </a>
            </div>

            <div className="flex items-center gap-8 pt-6 border-t border-white/10">
              <div>
                <div className="text-3xl font-bold text-blue-400">500+</div>
                <div className="text-sm text-slate-400">Tamamlanan Proje</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-400">15+</div>
                <div className="text-sm text-slate-400">Yıllık Deneyim</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-400">98%</div>
                <div className="text-sm text-slate-400">Müşteri Memnuniyeti</div>
              </div>
            </div>
          </div>

          <div className="relative hidden lg:block">
            <div className="relative bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 p-8 shadow-2xl">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Analiz Türü</span>
                  <TrendingUp className="w-5 h-5 text-blue-400" />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Regresyon Analizi</span>
                    <div className="flex-1 mx-4 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full w-[95%] bg-gradient-to-r from-blue-500 to-blue-400 rounded-full"></div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm">ANOVA</span>
                    <div className="flex-1 mx-4 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full w-[88%] bg-gradient-to-r from-green-500 to-green-400 rounded-full"></div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm">Yapısal Eşitlik</span>
                    <div className="flex-1 mx-4 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full w-[92%] bg-gradient-to-r from-purple-500 to-purple-400 rounded-full"></div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm">Faktör Analizi</span>
                    <div className="flex-1 mx-4 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full w-[85%] bg-gradient-to-r from-orange-500 to-orange-400 rounded-full"></div>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-white/10">
                  <div className="text-sm text-slate-400 mb-2">Son Tamamlanan Projeler</div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-3 text-sm">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      <span>Doktora Tezi - Sağlık Bilimleri</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      <span>Makale - Ekonometrik Analiz</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      <span>Yüksek Lisans - Sosyal Bilimler</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
