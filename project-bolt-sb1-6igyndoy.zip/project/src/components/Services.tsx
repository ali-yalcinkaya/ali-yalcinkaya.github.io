import { Database, LineChart, FileText, Users, Brain, TrendingUp } from 'lucide-react';

const services = [
  {
    icon: Database,
    title: 'Veri Analizi ve Hazırlama',
    description: 'Ham verilerinizi analiz için hazırlıyoruz: veri temizleme, kodlama, eksik veri yönetimi ve veri setinin yapılandırılması.',
    features: [
      'Veri temizleme ve kontrolü',
      'Kodlama ve dönüştürme',
      'Eksik veri analizi',
      'Veri setinin SPSS/R/Python formatına dönüşümü'
    ],
    color: 'blue'
  },
  {
    icon: LineChart,
    title: 'Betimsel ve Kestirimsel İstatistikler',
    description: 'Temel istatistiklerden ileri düzey analizlere kadar geniş yelpazede hizmet sunuyoruz.',
    features: [
      'Frekans ve tanımlayıcı istatistikler',
      't-testi, ANOVA, Ki-Kare testleri',
      'Korelasyon ve regresyon analizleri',
      'Normallik ve homojenlik testleri'
    ],
    color: 'green'
  },
  {
    icon: Brain,
    title: 'İleri Düzey İstatistiksel Modelleme',
    description: 'Karmaşık araştırma sorularınız için sofistike analiz yöntemleri uyguluyoruz.',
    features: [
      'Yapısal Eşitlik Modellemesi (YEM)',
      'Çok Değişkenli Analiz Teknikleri',
      'Faktör ve Kümeleme Analizi',
      'Lojistik ve Çoklu Regresyon'
    ],
    color: 'purple'
  },
  {
    icon: FileText,
    title: 'Tez ve Makale İstatistik Raporları',
    description: 'Akademik standartlara uygun, detaylı ve yayın kalitesinde istatistik raporları hazırlıyoruz.',
    features: [
      'APA formatında tablolar ve grafikler',
      'Bulgular bölümü yazımı',
      'İstatistiksel yorumlama desteği',
      'Metodoloji bölümü danışmanlığı'
    ],
    color: 'orange'
  },
  {
    icon: Users,
    title: 'Biyoistatistik ve Sağlık Bilimleri',
    description: 'Sağlık bilimleri alanındaki araştırmalar için özel biyoistatistik danışmanlığı.',
    features: [
      'Klinik çalışma analizleri',
      'Sağkalım analizleri',
      'Tanısal test değerlendirmeleri',
      'Epidemiyolojik veri analizleri'
    ],
    color: 'red'
  },
  {
    icon: TrendingUp,
    title: 'Ekonometri ve Zaman Serisi',
    description: 'Ekonomik ve finansal verilerin analizinde uzman ekonometrik danışmanlık hizmeti.',
    features: [
      'Panel veri analizleri',
      'Zaman serisi ve trend analizleri',
      'Nedensellik testleri',
      'Eşbütünleşme analizleri'
    ],
    color: 'teal'
  }
];

const colorClasses: Record<string, { bg: string; icon: string; border: string }> = {
  blue: { bg: 'bg-blue-50', icon: 'text-blue-600', border: 'border-blue-200' },
  green: { bg: 'bg-green-50', icon: 'text-green-600', border: 'border-green-200' },
  purple: { bg: 'bg-purple-50', icon: 'text-purple-600', border: 'border-purple-200' },
  orange: { bg: 'bg-orange-50', icon: 'text-orange-600', border: 'border-orange-200' },
  red: { bg: 'bg-red-50', icon: 'text-red-600', border: 'border-red-200' },
  teal: { bg: 'bg-teal-50', icon: 'text-teal-600', border: 'border-teal-200' }
};

export default function Services() {
  return (
    <section id="services" className="py-24 bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            İstatistiksel Danışmanlık Hizmetlerimiz
          </h2>
          <p className="text-xl text-slate-600">
            Akademik araştırmanızın her aşamasında, veri toplama sürecinden yayın aşamasına kadar profesyonel destek
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            const colors = colorClasses[service.color];

            return (
              <div
                key={index}
                className="bg-white rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 p-8 border border-slate-200 hover:-translate-y-1"
              >
                <div className={`inline-flex items-center justify-center w-14 h-14 rounded-xl ${colors.bg} border ${colors.border} mb-6`}>
                  <Icon className={`w-7 h-7 ${colors.icon}`} />
                </div>

                <h3 className="text-xl font-bold text-slate-900 mb-3">
                  {service.title}
                </h3>

                <p className="text-slate-600 mb-6 leading-relaxed">
                  {service.description}
                </p>

                <ul className="space-y-3">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-sm text-slate-700">
                      <svg className={`w-5 h-5 ${colors.icon} flex-shrink-0 mt-0.5`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <div className="mt-16 text-center">
          <a
            href="#contact"
            className="inline-flex items-center justify-center px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl hover:-translate-y-0.5"
          >
            Projeniz İçin Teklif Alın
          </a>
        </div>
      </div>
    </section>
  );
}
