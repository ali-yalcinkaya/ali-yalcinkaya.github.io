import { useState } from 'react';
import { Mail, Phone, Clock, Send, CheckCircle2 } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    projectType: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            Hemen İletişime Geçin
          </h2>
          <p className="text-xl text-slate-600">
            Projeniz için ücretsiz ön değerlendirme ve teklif alın. 24 saat içinde size geri dönüş yapıyoruz.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <div className="bg-slate-50 rounded-2xl p-8 border border-slate-200">
              {submitted ? (
                <div className="text-center py-12">
                  <CheckCircle2 className="w-20 h-20 text-green-600 mx-auto mb-6" />
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">Talebiniz Alındı!</h3>
                  <p className="text-lg text-slate-600">
                    En kısa sürede size geri dönüş yapacağız. Genellikle 24 saat içinde ilk değerlendirmeyi tamamlıyoruz.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-slate-900 mb-2">
                        Ad Soyad
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                        placeholder="Adınız ve soyadınız"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-slate-900 mb-2">
                        E-posta
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                        placeholder="ornek@email.com"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-slate-900 mb-2">
                        Telefon
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                        placeholder="0555 123 45 67"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-slate-900 mb-2">
                        Proje Türü
                      </label>
                      <select
                        name="projectType"
                        value={formData.projectType}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                      >
                        <option value="">Seçiniz</option>
                        <option value="yuksek-lisans">Yüksek Lisans Tezi</option>
                        <option value="doktora">Doktora Tezi</option>
                        <option value="makale">Makale</option>
                        <option value="proje">Araştırma Projesi</option>
                        <option value="diger">Diğer</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-2">
                      Proje Detayları
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={6}
                      className="w-full px-4 py-3 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all resize-none"
                      placeholder="Araştırma konunuz, veri setiniz ve ihtiyaç duyduğunuz analizler hakkında kısaca bilgi verin..."
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-3 px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl hover:-translate-y-0.5"
                  >
                    <Send className="w-5 h-5" />
                    Ücretsiz Teklif Alın
                  </button>
                </form>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-slate-900 text-white rounded-2xl p-8">
              <h3 className="text-xl font-bold mb-6">İletişim Bilgileri</h3>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-blue-600 rounded-lg p-3">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-semibold mb-1">E-posta</div>
                    <a href="mailto:istatistik@danismanlik.com" className="text-slate-300 hover:text-white transition-colors">
                      istatistik@danismanlik.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-blue-600 rounded-lg p-3">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-semibold mb-1">Telefon</div>
                    <a href="tel:+905551234567" className="text-slate-300 hover:text-white transition-colors">
                      +90 555 123 45 67
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-blue-600 rounded-lg p-3">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-semibold mb-1">Çalışma Saatleri</div>
                    <div className="text-slate-300">
                      Pazartesi - Cuma<br />
                      09:00 - 18:00
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 rounded-2xl p-8 border border-blue-100">
              <h3 className="text-lg font-bold text-slate-900 mb-4">Hızlı Yanıt Garantisi</h3>
              <p className="text-slate-600 mb-4">
                Tüm taleplere 24 saat içinde yanıt veriyoruz. Acil durumlar için telefon iletişimi tercih edebilirsiniz.
              </p>
              <div className="flex items-center gap-2 text-sm text-blue-700 font-semibold">
                <CheckCircle2 className="w-5 h-5" />
                <span>Ücretsiz ön değerlendirme</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
