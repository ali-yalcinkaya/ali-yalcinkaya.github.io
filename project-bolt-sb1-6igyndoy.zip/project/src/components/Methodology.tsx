import { CheckCircle2, Code2, FileCheck, MessageSquare } from 'lucide-react';

const tools = [
  {
    name: 'SPSS',
    description: 'Sosyal bilimler için endüstri standardı',
    expertise: 95
  },
  {
    name: 'R',
    description: 'İleri düzey istatistiksel modelleme',
    expertise: 90
  },
  {
    name: 'Python',
    description: 'Makine öğrenimi ve büyük veri analizi',
    expertise: 85
  },
  {
    name: 'AMOS',
    description: 'Yapısal eşitlik modellemesi',
    expertise: 92
  },
  {
    name: 'LISREL',
    description: 'İleri düzey YEM analizleri',
    expertise: 88
  },
  {
    name: 'Stata',
    description: 'Ekonometrik ve panel veri analizleri',
    expertise: 87
  }
];

const process = [
  {
    icon: MessageSquare,
    title: 'İlk Görüşme ve İhtiyaç Analizi',
    description: 'Araştırma sorularınızı ve veri setinizi değerlendiriyoruz. Hangi analizlerin gerekli olduğunu belirliyor ve size özel bir çalışma planı oluşturuyoruz.',
    duration: '1-2 gün'
  },
  {
    icon: CheckCircle2,
    title: 'Veri Kontrolü ve Hazırlık',
    description: 'Verilerinizi detaylı olarak inceliyoruz. Eksik veriler, aykırı değerler ve veri yapısını analiz edip gerekli düzeltmeleri yapıyoruz.',
    duration: '2-3 gün'
  },
  {
    icon: Code2,
    title: 'İstatistiksel Analiz',
    description: 'Belirlenen yöntemlerle analizlerinizi gerçekleştiriyoruz. Tüm varsayımları test ediyor ve sonuçları titizlikle kontrol ediyoruz.',
    duration: '3-5 gün'
  },
  {
    icon: FileCheck,
    title: 'Raporlama ve Yorumlama',
    description: 'APA formatında tablolar ve grafikler hazırlıyoruz. Bulgularınızı yorumluyor ve tez/makale yazımınız için destek sağlıyoruz.',
    duration: '2-3 gün'
  }
];

const methods = [
  'Parametrik ve Parametrik Olmayan Testler',
  'Çoklu ve Lojistik Regresyon Analizi',
  'Faktör Analizi (AFA ve DFA)',
  'Yapısal Eşitlik Modellemesi (YEM)',
  'Aracılık ve Düzenleyicilik Analizleri',
  'ANOVA ve MANOVA',
  'Güvenilirlik ve Geçerlilik Analizleri',
  'Panel Veri ve Zaman Serisi Analizleri',
  'Kümeleme ve Diskriminant Analizi',
  'Yaşam Analizi ve Sağkalım Analizleri',
  'Meta Analiz',
  'Bayesian İstatistik'
];

export default function Methodology() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            Çalışma Sürecimiz ve Uzmanlık Alanlarımız
          </h2>
          <p className="text-xl text-slate-600">
            Akademik standartlara uygun, şeffaf ve sonuç odaklı bir yaklaşımla çalışıyoruz
          </p>
        </div>

        <div className="mb-20">
          <h3 className="text-2xl font-bold text-slate-900 mb-8 text-center">Analiz Süreci</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="relative">
                  <div className="text-center">
                    <div className="relative inline-flex items-center justify-center mb-6">
                      <div className="absolute inset-0 bg-blue-100 rounded-full blur-xl opacity-50"></div>
                      <div className="relative bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center">
                        <Icon className="w-8 h-8" />
                      </div>
                    </div>

                    <div className="absolute top-8 left-1/2 w-full h-0.5 bg-gradient-to-r from-blue-200 to-transparent -z-10 hidden lg:block"></div>

                    <h4 className="text-lg font-bold text-slate-900 mb-3">
                      {step.title}
                    </h4>
                    <p className="text-sm text-slate-600 mb-3 leading-relaxed">
                      {step.description}
                    </p>
                    <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 text-xs font-semibold px-3 py-1.5 rounded-full">
                      {step.duration}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-20">
          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-8">Kullandığımız Yazılımlar</h3>
            <div className="space-y-6">
              {tools.map((tool, index) => (
                <div key={index} className="bg-slate-50 rounded-lg p-6 border border-slate-200">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h4 className="font-bold text-slate-900">{tool.name}</h4>
                      <p className="text-sm text-slate-600">{tool.description}</p>
                    </div>
                    <span className="text-2xl font-bold text-blue-600">{tool.expertise}%</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full transition-all duration-1000"
                      style={{ width: `${tool.expertise}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-8">İstatistiksel Yöntemler</h3>
            <div className="bg-slate-50 rounded-lg p-8 border border-slate-200">
              <div className="grid grid-cols-1 gap-4">
                {methods.map((method, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <svg className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-slate-700">{method}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-12 text-white text-center">
          <h3 className="text-3xl font-bold mb-4">Size Özel Analiz Planı Oluşturalım</h3>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Her projenin kendine özgü gereksinimleri vardır. Araştırmanız için en uygun yöntemleri birlikte belirleyelim.
          </p>
          <a
            href="#contact"
            className="inline-flex items-center justify-center px-8 py-4 bg-white text-blue-600 font-semibold rounded-lg hover:bg-blue-50 transition-all duration-200 shadow-lg hover:shadow-xl hover:-translate-y-0.5"
          >
            Ücretsiz Danışmanlık Randevusu Alın
          </a>
        </div>
      </div>
    </section>
  );
}
