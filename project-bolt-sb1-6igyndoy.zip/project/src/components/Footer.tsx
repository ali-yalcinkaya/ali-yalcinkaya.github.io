import { BarChart3 } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-blue-600 p-2 rounded-lg">
                <BarChart3 className="w-6 h-6" />
              </div>
              <span className="text-xl font-bold">İstatistik Danışmanlık</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Akademik araştırmalarınız için profesyonel istatistiksel danışmanlık hizmetleri.
              Tez ve makalelerinizde güvenilir analiz ve raporlama desteği.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-4">Hizmetler</h4>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#services" className="hover:text-white transition-colors">Veri Analizi</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">İstatistiksel Modelleme</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Tez Danışmanlığı</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Biyoistatistik</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">İletişim</h4>
            <ul className="space-y-2 text-slate-400">
              <li>istatistik@danismanlik.com</li>
              <li>+90 555 123 45 67</li>
              <li>Pzt-Cum: 09:00 - 18:00</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-400 text-sm">
            {currentYear} İstatistik Danışmanlık. Tüm hakları saklıdır.
          </p>
          <div className="flex gap-6 text-sm text-slate-400">
            <a href="#" className="hover:text-white transition-colors">Gizlilik Politikası</a>
            <a href="#" className="hover:text-white transition-colors">Kullanım Şartları</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
