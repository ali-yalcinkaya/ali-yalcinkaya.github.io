import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Dr. Ayşe Kaya',
    role: 'Doktora Öğrencisi, Sağlık Bilimleri',
    university: 'İstanbul Üniversitesi',
    text: 'Doktora tezimin istatistik kısmında çok değerli destek aldım. Yapısal eşitlik modellemesini hem AMOS hem de R ile çalıştık. Sonuçlar akademik jüri tarafından çok beğenildi. Özellikle her adımı detaylıca açıklama şekli ve raporlama kalitesi mükemmeldi.',
    rating: 5
  },
  {
    name: 'Prof. Dr. Mehmet Yılmaz',
    role: 'Öğretim Üyesi',
    university: 'Hacettepe Üniversitesi',
    text: 'SCI dergisine göndereceğim makale için ekonometrik analizleri birlikte yaptık. Panel veri analizi ve nedensellik testlerinde uzman desteği çok kritikti. Makale ilk hakemlerden olumlu geri dönüş aldı. Profesyonel yaklaşımı ve zamanında teslimatı için teşekkür ederim.',
    rating: 5
  },
  {
    name: 'Zeynep Demir',
    role: 'Yüksek Lisans Öğrencisi',
    university: 'Boğaziçi Üniversitesi',
    text: 'SPSS konusunda hiç bilgim yoktu. Sıfırdan başlayıp tezimin tüm istatistik bölümünü birlikte tamamladık. Sadece analiz yapmakla kalmadı, aynı zamanda sonuçları nasıl yorumlayacağımı ve yazacağımı da öğretti. İstatistikten korkmaz hale geldim.',
    rating: 5
  },
  {
    name: 'Doç. Dr. Can Öztürk',
    role: 'Öğretim Üyesi',
    university: 'ODTÜ',
    text: 'Araştırma projemiz için biyoistatistik danışmanlığı aldık. Klinik çalışma verilerinin analizinde ve raporlanmasında gösterdiği titizlik ve uzmanlık takdire şayan. Özellikle sağkalım analizleri ve tanısal test değerlendirmelerinde çok yardımcı oldu.',
    rating: 5
  },
  {
    name: 'Ahmet Şahin',
    role: 'Doktora Öğrencisi, İşletme',
    university: 'Marmara Üniversitesi',
    text: 'Tezimde aracılık ve düzenleyicilik analizleri yapacaktım ama PROCESS makrosu konusunda zorlanıyordum. Hem SPSS hem de R üzerinden analizleri gerçekleştirdik. Bulgular bölümünü yazmamda da çok yardımcı oldu. Kesinlikle tavsiye ederim.',
    rating: 5
  },
  {
    name: 'Dr. Elif Arslan',
    role: 'Araştırma Görevlisi',
    university: 'Ankara Üniversitesi',
    text: 'Makale için meta analiz yapmam gerekiyordu. Literatür taramasından etki büyüklüğü hesaplamalarına, heterojenlik analizlerinden yayın yanlılığı testlerine kadar tüm süreçte yanımda oldu. Sonuç olarak çok kaliteli bir çalışma ortaya çıktı.',
    rating: 5
  }
];

const stats = [
  { label: 'Tamamlanan Tez', value: '500+' },
  { label: 'Yayınlanan Makale', value: '150+' },
  { label: 'Müşteri Memnuniyeti', value: '%98' },
  { label: 'Tekrar Çalışma Oranı', value: '%85' }
];

export default function Testimonials() {
  return (
    <section className="py-24 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            Müşteri Deneyimleri
          </h2>
          <p className="text-xl text-slate-600">
            Akademisyenler ve araştırmacıların başarı hikayelerini okuyun
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-8 text-center border border-slate-200">
              <div className="text-4xl font-bold text-blue-600 mb-2">{stat.value}</div>
              <div className="text-slate-600 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 p-8 border border-slate-200 relative"
            >
              <Quote className="absolute top-6 right-6 w-10 h-10 text-blue-100" />

              <div className="flex gap-1 mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                ))}
              </div>

              <p className="text-slate-700 leading-relaxed mb-6 relative z-10">
                {testimonial.text}
              </p>

              <div className="pt-6 border-t border-slate-100">
                <div className="font-bold text-slate-900">{testimonial.name}</div>
                <div className="text-sm text-slate-600">{testimonial.role}</div>
                <div className="text-sm text-blue-600 font-medium">{testimonial.university}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-blue-50 rounded-2xl p-12 border border-blue-100">
          <div className="max-w-3xl mx-auto text-center">
            <h3 className="text-2xl font-bold text-slate-900 mb-4">
              Referanslarımızı Öğrenmek İster misiniz?
            </h3>
            <p className="text-lg text-slate-600 mb-8">
              Gizlilik anlaşmaları çerçevesinde, daha önce çalıştığımız akademisyenlerle iletişime geçebilir ve deneyimlerini öğrenebilirsiniz.
            </p>
            <a
              href="#contact"
              className="inline-flex items-center justify-center px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl hover:-translate-y-0.5"
            >
              İletişime Geçin
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
